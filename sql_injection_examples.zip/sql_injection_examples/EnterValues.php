<?php
echo "<h1><b>Insert data in to the database using mysql prepared statements<b></h1><br><br>";

echo'<center><form name="login_form" method="GET" action="preparedStatement.php">

	 Enter username       <input type="text" name="username" placeholder="username" style="width:400px"/><br><br>
	 Enter new password   <input type="text" name="password" placeholder="password" style="width:400px"/><br><br>
	 <input type="submit" value="send"/>
	 </form></center>
';



?>