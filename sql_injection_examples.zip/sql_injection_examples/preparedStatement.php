<?php

$servername = "localhost";
$username_mysql = "root";
$password_mysql = "";
$dbname = "mysqlinjection";
$conn = new mysqli($servername, $username_mysql, $password_mysql, $dbname);
if ($conn->connect_error) {
	echo 'error';
} 
echo "successfull<br>";


if($preparedStatement = $conn->prepare("INSERT INTO usersprepared(username, password) VALUES(?, ?)")){
$preparedStatement->bind_param("ss", $username, $password);
$username = $_GET['username'];
$password = $_GET['password'];
$preparedStatement->execute();

}
$conn->close();









?>