<?php
$servername = "localhost";
$username_mysql = "root";
$password_mysql = "";
$dbname = "mysqlinjection";
$conn = new mysqli($servername, $username_mysql, $password_mysql, $dbname);
if ($conn->connect_error) {
	echo 'error';
} 
echo "successfull<br>";
$username = $_GET['username'];
$password = $_GET['password'];

$q = "UPDATE users SET password  = '$password'  WHERE username  = '$username' ";

if($conn->multi_query($q)===TRUE){
	echo "Updated";
}
else{echo"error";}
$conn->close();

?>