<?php
$servername = "localhost";
$username_mysql = "root";
$password_mysql = "";
$dbname = "mysqlinjection";
$conn = new mysqli($servername, $username_mysql, $password_mysql, $dbname);
if ($conn->connect_error) {
	echo 'error';
} 
echo "successfull<br>";
$username = $_GET['username'];
$password = $_GET['password'];

$q = "INSERT INTO users (username, password)
VALUES (' $username ', ' $password ')";
// multiple queries gaddi possible
if($conn->multi_query($q)===TRUE){
	echo "Record added";
}
else{echo"error";}
$conn->close();

?>