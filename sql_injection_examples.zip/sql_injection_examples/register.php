
<?php

echo "<h1><b>SecurityVibes SQL injection Example<b></h1><br><br>";

echo'<center><form name="login_form" method="GET" action="InsertQuery.php">

	 Enter username <input type="text" name="username" placeholder="username" style="width:400px"/><br><br>
	 Enter password <input type="text" name="password" placeholder="password" style="width:400px"/><br><br>
	 <input type="submit" value="Register"/>
	 </form></center>
';





?>