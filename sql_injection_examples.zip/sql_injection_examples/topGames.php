<?php
$servername = "localhost";
$username_mysql = "root";
$password_mysql = "";
$dbname = "mysqlinjection";
$conn = new mysqli($servername, $username_mysql, $password_mysql, $dbname);
if ($conn->connect_error) {
	echo 'error';
} 
$type = $_GET['type'];
$query="SELECT name,category FROM $type";


$result = mysqli_query($conn, $query);
$num = mysqli_num_rows($result);

echo "Game===============Category <br><br>";
while($row = $result->fetch_row()){

echo $row[0]." ----------------------- ".$row[1]."<br>";

}
$conn->close();

?>