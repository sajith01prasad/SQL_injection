<?php

echo'<center><form name="login_form" method="GET" action="topGames.php">

	 Enter type <input type="text" name="type" placeholder="type" style="width:400px"/><br><br>
	
	 <input type="submit" value="Search"/>
	 </form></center>
';









?>